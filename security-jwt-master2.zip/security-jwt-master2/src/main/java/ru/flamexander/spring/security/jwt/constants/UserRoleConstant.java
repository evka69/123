package ru.flamexander.spring.security.jwt.constants;

public interface UserRoleConstant {
    String USER = "USER";
    String ADMIN = "ADMIN";
}
