package ru.flamexander.spring.security.jwt.constants;

public interface Errors {
}
